from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction
from pybricks.robotics import DriveBase

hub = PrimeHub()

# Ajusta la dirección si tu robot no avanza recto
motor_izq = Motor(Port.B, Direction.CLOCKWISE)
motor_der = Motor(Port.F, Direction.COUNTERCLOCKWISE)

# Ajusta estas medidas según tu robot
robot = DriveBase(motor_izq, motor_der, wheel_diameter=56, axle_track=120)

# Velocidad y giro
robot.settings(straight_speed=250, straight_acceleration=300,
               turn_rate=120, turn_acceleration=200)

# 1. Salir un poco hacia adelante desde la base
robot.straight(120)

# 2. Bajar recto por el carril
robot.straight(280)

# 3. Girar a la izquierda
robot.turn(-90)

# 4. Avanzar un poco hacia adelante
robot.straight(140)