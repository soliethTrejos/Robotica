from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

motor_izq = Motor(Port.B, Direction.CLOCKWISE)
motor_der = Motor(Port.F, Direction.COUNTERCLOCKWISE)
sensor_linea = ColorSensor(Port.A)

robot = DriveBase(motor_izq, motor_der, wheel_diameter=56, axle_track=120)

robot.settings(
    straight_speed=960,
    straight_acceleration=960,
    turn_rate=220,
    turn_acceleration=960
)

def cm(valor):
    return valor * 10

robot.straight(cm(2.5))
robot.turn(135)
robot.straight(cm(-6))

while True:
    if sensor_linea.reflection() <= 20:   # negro
        robot.straight(cm(-89))
        break

    wait(10)



